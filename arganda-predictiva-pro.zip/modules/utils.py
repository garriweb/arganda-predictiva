
def format_number(num):
    return f"{num:,.0f}".replace(",", ".")
