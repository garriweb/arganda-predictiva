def get_weather_today(): return {'rain':2.7,'temp':18.3}
