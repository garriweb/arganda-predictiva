def get_unemployment_series(): return {'last':3341}
