def get_dgt_incidents(): return {'today':4}
