# app placeholder
print("Arganda Predictiva Streamlit App")
